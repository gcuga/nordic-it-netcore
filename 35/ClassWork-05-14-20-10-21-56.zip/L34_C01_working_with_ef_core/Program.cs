﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace L34_C01_working_with_ef_core
{
	class Person
	{
		public string FirstName { get; set; }
	}

	class Program
	{
		static void Main()
		{
			//List<Person> persons = new List<Person>
			//{
			//	new Person {FirstName = "Andrei;"},
			//	new Person {FirstName = "Aaron;"}
			//};

			//var s = persons.Where(x => x.FirstName.StartsWith("An"));

			Console.WriteLine("Hello World!");
		}
	}
}
