﻿using System;

namespace L34_C02_working_with_ef_core_final
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
		}
	}
}
