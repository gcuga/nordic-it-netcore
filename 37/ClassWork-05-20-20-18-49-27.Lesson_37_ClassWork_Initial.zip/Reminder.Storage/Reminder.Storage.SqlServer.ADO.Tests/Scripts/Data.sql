﻿-- Fill some data
-- 1
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-111111111111',
	'ContactId_1',
	'2020-01-01 00:00:00 +00:00',
	'Message_1',
	0,
	'2019-01-01 00:00:00 +00:00',
	'2019-01-01 00:00:00 +00:00')
-- 2
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-222222222222',
	'ContactId_2',
	'2020-02-02 00:00:00 +00:00',
	'Message_2',
	0,
	'2019-02-02 00:00:00 +00:00',
	'2019-02-02 00:00:00 +00:00')
-- 3
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-333333333333',
	'ContactId_3',
	'2020-03-03 00:00:00 +00:00',
	'Message_3',
	1,
	'2019-03-03 00:00:00 +00:00',
	'2019-03-03 00:00:00 +00:00')
-- 4
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-444444444444',
	'ContactId_4',
	'2020-04-04 00:00:00 +00:00',
	'Message_4',
	2,
	'2019-04-04 00:00:00 +00:00',
	'2019-04-04 00:00:00 +00:00')
-- 5
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-555555555555',
	'ContactId_5',
	'2020-05-05 00:00:00 +00:00',
	'Message_5',
	2,
	'2019-05-05 00:00:00 +00:00',
	'2019-05-05 00:00:00 +00:00')
-- 6
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-666666666666',
	'ContactId_6',
	'2020-06-06 00:00:00 +00:00',
	'Message_6',
	3,
	'2019-06-06 00:00:00 +00:00',
	'2019-06-06 00:00:00 +00:00')
-- 7
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-777777777777',
	'ContactId_7',
	'2020-07-07 00:00:00 +00:00',
	'Message_7',
	3,
	'2019-07-07 00:00:00 +00:00',
	'2019-07-07 00:00:00 +00:00')
-- 8
INSERT INTO [dbo].[ReminderItem] (
	[Id],
	[ContactId],
	[TargetDate],
	[Message],
	[StatusId],
	[CreatedDate],
	[UpdatedDate]) 
VALUES (
	'00000000-0000-0000-0000-888888888888',
	'ContactId_8',
	'2020-08-08 00:00:00 +00:00',
	'Message_8',
	3,
	'2019-08-08 00:00:00 +00:00',
	'2019-08-08 00:00:00 +00:00')